﻿public class LightManagerFogLights : LightManager<FogLight>
{

}
