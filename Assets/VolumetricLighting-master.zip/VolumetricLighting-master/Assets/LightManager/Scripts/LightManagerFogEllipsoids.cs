﻿public class LightManagerFogEllipsoids : LightManager<FogEllipsoid>
{

}
